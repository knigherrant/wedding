<?php
/*
 # Module		JK Invitation
 # @version		3.0.1
 # ------------------------------------------------------------------------
 # author    PHPKungfu Solutions Co
 # copyright Copyright © 2008-2012 phpkungfu.club. All Rights Reserved.
 # @license - http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL or later.
 # Websites: http://www.phpkungfu.club
 # Technical Support:  http://www.phpkungfu.club/my-tickets.html
-------------------------------------------------------------------------*/

// No direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );