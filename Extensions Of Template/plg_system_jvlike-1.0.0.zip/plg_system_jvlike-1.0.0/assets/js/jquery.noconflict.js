$JVLIKE = jQuery.noConflict();
