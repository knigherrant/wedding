DROP TABLE IF EXISTS `#__jkcustomfields_categories`;
DROP TABLE IF EXISTS `#__jkcustomfields_clients`;
DROP TABLE IF EXISTS `#__jkcustomfields_comments`;
DROP TABLE IF EXISTS `#__jkcustomfields_config`;
DROP TABLE IF EXISTS `#__jkcustomfields_documents`;
DROP TABLE IF EXISTS `#__jkcustomfields_inbox`;
DROP TABLE IF EXISTS `#__jkcustomfields_form`;
DROP TABLE IF EXISTS `#__jkcustomfields_projects`;
DROP TABLE IF EXISTS `#__jkcustomfields_logcalls`;
DROP TABLE IF EXISTS `#__jkcustomfields_proofs`;
DROP TABLE IF EXISTS `#__jkcustomfields_sales`;
DROP TABLE IF EXISTS `#__jkcustomfields_statistics`;
DROP TABLE IF EXISTS `#__jkcustomfields_templates`;
